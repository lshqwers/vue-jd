<template>
  <div class="app">
    <!-- 
      Error in render: "TypeError: Cannot read property 'matched' of undefined"
      found in
     -->
       <router-view></router-view>  
      <div class="tabs">
        <!-- 这里的to是routes配置的path路径 -->
      <router-link to='/home' tag='span' active-class='on'>首页</router-link>
      <router-link to='/about' tag='span' active-class='on'>发现</router-link>
      <router-link to='/my' tag='span' active-class='on'>我的</router-link>
      </div>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {}
};
</script>

<style>
span{
  width: 40px;
  height: 40px;
}
.on{
  color: red
}
</style>
