// 这个个是路口文件
// 引入vue
import Vue from 'vue'
// 引入根组件
import App from './App.vue'
// 关闭项目启动的生产提示
Vue.config.productionTip = false
// 引入router  To install it, you can run: npm install --save router一定要使用./这个路径
import Router from './router'
// 注册路由
// App.use(Router)
// new Vue的实例
new Vue({
  Router,
  render: h => h(App),
}).$mount('#app') 
// 手动挂载 $mount
