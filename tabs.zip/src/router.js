// 引入vue
// 引入vue-router
// from单词 不要写错了
import Vue from 'vue'
import VueRouter from 'vue-router'
// 注册路由 (不要忘记了)
Vue.use(VueRouter)
// 引入组件 (不要忘记了) ./views/Home 不要忘记了是.vue
import Home  from  './views/Home.vue'
import About from  './views/About.vue'
import My    from  './views/My.vue'
// routes不是, 而是router
// 路由的配置 path是路径 component组件的名字
// 要创建实例路由
// const router=new  VueRouter({
// //       routes:[
// //         {path:'/home', component:Home},
// //         {path:'/about',component:About},
// //         {path:'/my',   component:My},
// //     ]
// // })
let router = new VueRouter({
    routes: [
      { path: '/home', component: Home },
      { path: '/about', component: About },
      { path: '/my', component: My }
    ]
  })
// 暴露路由
export default router