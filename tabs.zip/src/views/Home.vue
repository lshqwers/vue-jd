<template class="shouye">
     <h1>home页</h1>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>

</style>


